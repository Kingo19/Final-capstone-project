<template>
    <div class="image-container">
      <img src="https://t1.gstatic.com/licensed-image?q=tbn:ANd9GcSVhJ46pOBVylg5_ZnYilSr14xSgJwSZ386f8C6hRKrA0MRiCpn2ozG-Bfcxa3bSdJ-" alt="Image 1">
      <img src="../assets/foot6.jpg" alt="Image 2">
      <img src="../assets/fo0t2.jpg" alt="Image 3">
      <img src="../assets/foot3.jpg" alt="Image 4">
      <img src="../assets/foot4.jpg" alt="Image 5">
      <img src="../assets/foot1.jpg" alt="Image 6">
    </div>
  </template>
  
  <script>
  export default {
   
  };
  </script>
  
  <style scoped>
  .image-container {
    display: flex;
    overflow: hidden;
  }
  
  .image-container img {
    width: 300px; 
    height: 300px;
    margin: 0;
  }
  </style>
