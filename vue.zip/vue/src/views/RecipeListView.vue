<template>
  <div>
    <RecipeListPage/>
  </div>
</template>

<script>
import RecipeListPage
  from "../components/RecipeListPage.vue";

export default {
  components: {
    RecipeListPage,
  },
};
</script>
