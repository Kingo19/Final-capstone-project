<template>
  <div>
    <RecipeListPage/>
  </div>
</template>

<script>
import RecipeListPage
  from "./RecipeListPage.vue";

export default {
  components: {
    RecipeListPage,
  },
};
</script>
